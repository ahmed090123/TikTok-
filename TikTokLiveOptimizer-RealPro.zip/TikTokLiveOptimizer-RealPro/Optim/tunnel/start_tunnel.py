import os
print('[*] Starting secure gost tunnel...')
os.system('gost -L=:1080')
